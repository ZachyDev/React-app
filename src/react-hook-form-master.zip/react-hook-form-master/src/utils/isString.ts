export default (value: unknown): value is string => typeof value === 'string';
