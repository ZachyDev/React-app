export default (val: unknown): val is undefined => val === undefined;
