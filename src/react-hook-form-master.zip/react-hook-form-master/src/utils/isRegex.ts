export default (value: unknown): value is RegExp => value instanceof RegExp;
