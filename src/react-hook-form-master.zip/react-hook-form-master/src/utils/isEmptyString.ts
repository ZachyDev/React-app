export default (value: string) => value === '';
