# App for cypress automation

## Install

    $ npm i && npm start
